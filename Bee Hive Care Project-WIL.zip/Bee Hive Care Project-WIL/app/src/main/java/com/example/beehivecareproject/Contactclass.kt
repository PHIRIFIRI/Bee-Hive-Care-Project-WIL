package com.example.beehivecareproject

data class Contactclass(val Name:String,val Email:String, val Subject:String, val Message:String)
