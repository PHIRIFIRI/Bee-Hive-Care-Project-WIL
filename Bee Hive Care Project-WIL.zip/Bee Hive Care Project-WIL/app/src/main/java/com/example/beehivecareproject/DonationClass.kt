package com.example.beehivecareproject
import java.time.LocalDate

data class DonationClass(val name:String, val Surname:String, val Email:String, val Phone:Int, val Password:String, val TypeOfDonate:String, val NumberofDonate:Int, val date:LocalDate,val Message:String)
